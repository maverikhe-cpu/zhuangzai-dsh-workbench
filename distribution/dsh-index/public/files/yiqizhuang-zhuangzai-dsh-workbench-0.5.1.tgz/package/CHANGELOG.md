# 0.5.1

- 转义 OAuth 回调错误页中的错误代码及描述，避免将回调参数解释为 HTML。
- 增加包含 HTML 标签、引号和特殊字符的回归测试。

# 0.5.0

- 同步装仔综合技能，覆盖原有 10 类交付管理场景；原技能名保留为兼容入口，避免两套规则冲突。
- 派工优先服务端缺口汇总，支持按需返回段、TopN、日期缩窗与重点下钻。
- 项目经理负荷支持公司独立完工规则、finalStages、直属/子部门范围及状态冲突清单；不二次扣减已排除的工地。
- 增加公司设备台账方法，明确绑定设备在线/离线计数及期间时长在线率的区别。
- 同步验收、批量进度、问题、月报等场景的数据口径和大任务性能规则。
- 两份预设共用同一角色文本，按需读取场景资料；保持现有工作台、会话续聊、头像和授权方式。
- 增加派工计算、技能包装及发布索引测试，公开独立索引的构建与部署配置。

# Changelog

## 0.4.3 — 2026-11-10

- Publish the standalone plugin source under the MIT license.
- Add public repository metadata, searchable keywords and installation documentation.
- Include the existing mascot asset and isolated OAuth / workbench interaction regression tests.
- Runtime code, 10 skills and agent presets are unchanged from the public 0.4.2 download.
